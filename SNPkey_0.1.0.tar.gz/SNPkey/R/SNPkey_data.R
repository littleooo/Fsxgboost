#' @name example_data
#' @title Run a examples for an in-development function.
#' @description 
#' A list including:
#' \itemize{
#' \item{marker:} {A matrix (1000 * 5000), each row represent 5,000 markers information for one individuals.}
#' \item{phenoype:} {The real phenotype value for each individual.}
#' }
#' @docType data
#' @usage data(example_data)
NULL