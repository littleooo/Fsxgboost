#'This is some descriptio of this function.
#' @title Build a genomic locus screening model using XGBoost and SVM algorith
#' @description The function applies the XGBoost model with SVM to build a screen model for genomic locus.
#' @param train_x A genotype matrix (N x M; N individuals, M markers) for training model
#' @param train_y Vector (N * 1) of phenotype for training model.
#' @param seed Set the seed random number.
#' @param xgbround (Integer) The number of iterations over training data to train the model, default = 1000.
#' @param loopnum (Integer) The number of iterations over parameter optimization, default = 1000.
#' @param sc The cost of svm model, default = 1.
#' @param sg The gamma of svm model, default =0.001.
#' @return a dataframe
#' @export
#' 

snpkey <- function(train_x,train_y,seednum=0,xgbround=1000,loopnum=500,sc=1,sg=0.001){
  requireNamespace("xgboost")
  requireNamespace("e1071")
  set.seed(seednum)
  index <- sample(1:length(train_y),round(length(train_y)*0.8))
  traindata1 <- data.matrix(train_x) 
  traindata3 <- as.numeric(train_y)
  traindata4 <- list(data=traindata1,label=traindata3) 
  dtrain <- xgb.DMatrix(data = traindata4$data, label = traindata4$label) 
  watchlist <- list(train = dtrain)
  rm(traindata1)
  rm(traindata3)
  rm(traindata4)
  gc()
  best_param = list()
  best_seed <- 0
  best_cor <- 0
  best_imp <- 0
  best_round <- 0
  best_rmse <- 0
  for(i in 1:loopnum){
    param <- list( max_depth = sample(2:4,1),
                   eta = runif(1,0.00000001,0.00001),
                   gamma = runif(1,0.8,1),
                   min_child_weight = sample(35:50,1),
                   subsample = runif(1,0.7,0.9),
                   colsample_bylevel =  runif(1,0.7,0.8),
                   lamda = sample(1:10,1)
    )
    seed.number <- sample.int(100,1)[[1]]
    set.seed(seed.number)
    fsxgb <- xgb.train(params = param,data = dtrain,watchlist=watchlist,nrounds = xgbround,verbose = T,maximize =F)
    nowimp <- xgb.importance(model = fsxgb)
    cname <- nowimp[,1]
    cname <- t(cname)
    cname <- as.vector(cname)
    now_x <- train_x[,colnames(train_x)%in%cname]
    vlitrain_x <- now_x[index,]
    vlitrain_y <- train_y[index]
    vlitest_x <-  now_x[-index,]
    vlitest_y <-  train_y[-index]
    rm(now_x)
    rm(fsxgb)
    gc()
    fssvm <- svm(vlitrain_x,vlitrain_y,cost=sc,gamma=sg,type="eps-regression",kernel = "radial")
    fspre <- predict(fssvm,vlitest_x)
    fscor <- cor(vlitest_y,fspre)
    fsrmse <- sqrt(sum((vlitest_y-fspre)^2)/length(vlitest_y))
    if(fscor>best_cor){
      best_cor <- fscor
      best_param <- param
      best_seed <-  seed.number
      best_imp <- nowimp
      best_rmse <-  fsrmse
    }
    rm(fssvm)
    gc()
  }
  bstn <- best_imp[,1]
  bstn <- t(bstn)
  bstn <- as.vector(bstn)
  results <-list(best_param=best_param,best_cor=best_cor,best_rmse=best_rmse,bestsnp=bstn)
  return(results)
}